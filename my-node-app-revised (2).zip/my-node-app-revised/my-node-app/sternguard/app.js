var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const initializeObjection = require('./db');
const authRouter = require('./routes/auth'); // Add this line
var usersGetter = require('./routes/UserRoutes');
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();
const knex = initializeObjection();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/auth', authRouter); // Add this line
app.use('/user',usersGetter);
const PORT = process.env.PORT

app.listen(PORT, () => {
    console.log('Server Started on ' + PORT);
});

module.exports = app;
