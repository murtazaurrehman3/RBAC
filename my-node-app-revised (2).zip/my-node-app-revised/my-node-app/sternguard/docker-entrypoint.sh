# npm run knexmigrate
node app.js
npx knex migrate:latest
